//
//  Appointment.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 3/13/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//


class Appointment: NSObject, NSCoding {
    
    //MARK: Properties
    
    var appointmentname: String
    var appointmentdate: String
    var appointmentmuscle: String
    
    //MARK: Archiving Paths
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("appointments")
    
    //MARK: Types
    
    struct PropertyKey {
        static let appointmentname = "appointmentname"
        static let appointmentdate = "appointmentdate"
        static let appointmentmuscle = "appointmentmuscle"
    }
    //MARK: Initialization
    
    init?(appointmentname: String, appointmentdate: String, appointmentmuscle: String) {
        
        // Initialization should fail if there is no name or if the rating is negative.
        guard !appointmentname.isEmpty else {
            return nil
        }
        
        guard !appointmentdate.isEmpty else {
            return nil
        }
        
        guard !appointmentmuscle.isEmpty else {
            return nil
        }
        
        // Initialize stored properties.
        self.appointmentname = appointmentname
        self.appointmentdate = appointmentdate
        self.appointmentmuscle = appointmentmuscle
        
    }
   //MARK: NSCoding
    func encode(with aCoder: NSCoder) {
        aCoder.encode(appointmentname, forKey: PropertyKey.appointmentname)
        aCoder.encode(appointmentdate, forKey: PropertyKey.appointmentdate)
        aCoder.encode(appointmentmuscle, forKey: PropertyKey.appointmentmuscle)
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        // The name is required. If we cannot decode a name string, the initializer should fail.
        guard let name = aDecoder.decodeObject(forKey: PropertyKey.appointmentname) as? String else {
            os_log("Unable to decode the name for a Meal object.", log: OSLog.default, type: .debug)
            return nil
        }
        
        // Because photo is an optional property of Meal, just use conditional cast.
        let date = aDecoder.decodeObject(forKey: PropertyKey.appointmentdate) as? String
        
        guard let muscle = aDecoder.decodeObject(forKey: PropertyKey.appointmentmuscle) as? String else {
            os_log("Unable to decode the name for a Meal object.", log: OSLog.default, type: .debug)
            return nil
        }
        
        // Must call designated initializer.
        self.init(appointmentname: name, appointmentdate: date!, appointmentmuscle: muscle)
        
    }
}
import UIKit
import os.log
