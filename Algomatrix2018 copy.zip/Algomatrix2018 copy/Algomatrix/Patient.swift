//
//  Patient.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 2/13/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//



class Patient: NSObject, NSCoding {
    
    //MARK: Properties
    
    var name: String
    var age: String
    var birth: String
    var comment: String

    //MARK: Archiving Paths
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("patients")
    
    //MARK: Types
    
    struct PropertyKey {
        static let name = "name"
        static let age = "age"
        static let birth = "birth"
        static let comment = "comment"
    }
    
//MARK: Initialization
    init?(name: String, age: String, birth: String, comment: String) {
    
    // The name must not be empty
    guard !name.isEmpty else {
        return nil
    }
        
    // The age must not be empty
    guard !age.isEmpty else {
        return nil
    }
        
    // The birth must not be empty
    guard !birth.isEmpty else {
        return nil
    }
    
    
    // Initialize stored properties.
    self.name = name
    self.age = age
    self.birth = birth
    self.comment = comment
}
    //MARK: NSCoding
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: PropertyKey.name)
        aCoder.encode(age, forKey: PropertyKey.age)
        aCoder.encode(birth, forKey: PropertyKey.birth)
        aCoder.encode(comment, forKey: PropertyKey.comment)
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        // The name is required. If we cannot decode a name string, the initializer should fail.
        guard let name = aDecoder.decodeObject(forKey: PropertyKey.name) as? String else {
            os_log("Unable to decode the name for a Patient object.", log: OSLog.default, type: .debug)
            return nil
        }
        
        // Because age is an optional property of Patient, just use conditional cast.
        let age = aDecoder.decodeObject(forKey: PropertyKey.age) as? String
        
        // Because birth is an optional property of Patient, just use conditional cast.
        let birth = aDecoder.decodeObject(forKey: PropertyKey.birth) as? String
        
        // Because comment is an optional property of Patient, just use conditional cast.
        let comment = aDecoder.decodeObject(forKey: PropertyKey.comment) as? String
        
        self.init(name: name, age: age!, birth: birth!, comment: comment!)
    }
}
import UIKit
import os.log
