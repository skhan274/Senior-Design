//
//  AppointmentInfoViewController.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 3/14/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//

import UIKit
import os.log
class AppointmentInfoViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate {
    
    @IBOutlet weak var appointmenttitleTextField: UITextField!
    @IBOutlet weak var appointmentdateTextField: UITextField!
    @IBOutlet weak var muscleTextView: UITextView!
    @IBOutlet weak var appointmentTitleLabel: UILabel!
    @IBOutlet weak var appointmentDateLabel: UILabel!
    @IBOutlet weak var appointmentMuscleLabel: UILabel!
    @IBOutlet weak var appointSaveButton: UIBarButtonItem!
    
    /*
     This value is either passed by `PatientTableViewController` in `prepare(for:sender:)`
     or constructed as part of adding a new meal.
     */
    var appointment: Appointment?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Handle the text field’s user input through delegate callbacks.
        appointmenttitleTextField.delegate = self
        appointmentdateTextField.delegate = self
        muscleTextView.delegate = self
        if let appointment = appointment {
            navigationItem.title = appointment.appointmentname
            appointmenttitleTextField.text   = appointment.appointmentname
            appointmentdateTextField.text = appointment.appointmentdate
            muscleTextView.text = appointment.appointmentmuscle
        }
        // Enable the Save button only if the text field has a valid Meal name.
        updateSaveButtonState()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Disable the Save button while editing.
        appointSaveButton.isEnabled = false
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        guard let button = sender as? UIBarButtonItem, button === appointSaveButton else {
            os_log("The save button was not pressed, cancelling", log: OSLog.default, type: .debug)
            return
        }
        let appointTitle = appointmenttitleTextField.text ?? ""
        let appointDate = appointmentdateTextField.text ?? ""
        let muscleView = muscleTextView.text ?? ""
        appointment = Appointment(appointmentname: appointTitle, appointmentdate: appointDate, appointmentmuscle: muscleView)
    }
    //MARK: Private Methods
    private func updateSaveButtonState() {
        // Disable the Save button if the text field is empty.
        let text = appointmenttitleTextField.text ?? ""
        appointSaveButton.isEnabled = !text.isEmpty
    }

}
