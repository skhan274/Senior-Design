//
//  PatientTableViewCell.swift
//  Algomatrix2018
//
//  Created by Saif Khan on 2/13/18.
//  Copyright © 2018 Saif Khan. All rights reserved.
//

import UIKit

class PatientTableViewCell: UITableViewCell {

    //MARK: Properties
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
